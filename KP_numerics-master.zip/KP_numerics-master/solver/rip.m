close all; clear; clc;
beep off;